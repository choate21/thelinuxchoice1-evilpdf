# EvilPDF v1.1
## Author: https://github.com/thelinuxchoice/evilpdf
## Twitter: https://twitter.com/linux_choice
### Read the license before using any part from this code :) 

Hiding executable files in PDF documents

![ep](https://user-images.githubusercontent.com/34893261/83931973-092ac980-a776-11ea-9680-a299902d5ae3.png)

## Legal disclaimer:

Usage of EvilPDF for attacking targets without prior mutual consent is illegal. It's the end user's responsibility to obey all applicable local, state and federal laws. Developers assume no liability and are not responsible for any misuse or damage caused by this program 

### Usage:
```
git clone https://github.com/thelinuxchoice/evilpdf
cd evilpdf
python -m pip install pypdf2
python evilpdf.py
```
### Donate!
Pay me a coffee:
### Paypal:
https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=CLKRT5QXXFJY4&source=url
